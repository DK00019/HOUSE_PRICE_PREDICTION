# # in this we should import flask module
# #from flask import Flask, request, jsonify  # this flask allows to write a py service which allows http request
# # here we need to configure the interpreter s o we go to setting
# # this is our main server file s o we created a app function
# #app = Flask(__name__)  # this line is for creating the app
#
# #@app.route('/hello')
# # this line of code is to represent the http endpoint , we we can run this server simply by python server.py
# #def hello():
#     #return "Hiiii...."  # this is to check our code
#
# #if __name__ == "__main__" :
#     #print("starting python flask server for house price prediction")
#     #app.run()  # in this main we run the app-- it runs the application on a specific port
#
# # with the url we get in terminal add our http endpoint we declared above
# # this above code is simply for understanding now lets write our original routine
# # we need teo routine one to show the locations which we have in the columns.json file that we exported
# # so now we create a subdirectory within this server directory called artifacts in which we copy our exported json and pickle file
# # now we have the artifacts in this subdirectory
# # in our for the first dropdown we have to have all the locations for which we have to write the routine
#
# from flask import Flask, request, jsonify
#
# app = Flask(__name__) # our main app
#
# #here we import that util file
# import util  # this will have the function called get location names
# @app.route('/get_location_names') #end of http
#
# def get_location_names(): # here we change our function to write original routine to get location, this returns all locations
#     #the way this returns all the locations is through jsonify
#
#     response = jsonify({
#         "locations" : util.get_location_names()
#     })
#     response.headers.add('Access-Control-Allow-Origin', '*')
#     return response  # in this we r returning a respomse which contains all the locations
# # for this location we r going to create a nwe file called util - this will contain all the core routines where as the server will just do the routing of request and response
# @app.route('/predict_home_price', methods = ['GET','POST'])  #this is another end point it takes HTTP-post method
# def predict_home_price():
#     total_sqft = float(request.form['total_sqft']) # the way it works is we have imported request class so whenever we make http call we get inputs in request forms
#     location = request.form['location']
#     bhk = int(request.form['bhk'])
#     bath = int(request.form['bath'])
#     # after getting all this inputs we need to call util.get_estimated_price func in which we will pass these input params which will return us estimated price
#     response = jsonify({
#         'estimated_price': util.get_estimated_price(location, total_sqft, bhk, bath)
#     })
# if __name__ == "__main__" : # to run app in the specific port
#     print("starting python flask server for house price prediction")
#     app.run()
#
# # this is our final flask server , to check it we can use post man application which allows us to check our http call


# refer above code for understanding

from flask import Flask, request, jsonify
import util

app = Flask(__name__)

@app.route('/get_location_names', methods=['GET'])
def get_location_names():
    response = jsonify({
        'locations': util.get_location_names()
    })
    response.headers.add('Access-Control-Allow-Origin', '*')

    return response

@app.route('/predict_home_price', methods=['GET', 'POST'])
def predict_home_price():
    total_sqft = float(request.form['total_sqft'])
    location = request.form['location']
    bhk = int(request.form['bhk'])
    bath = int(request.form['bath'])

    response = jsonify({
        'estimated_price': util.get_estimated_price(location,total_sqft,bhk,bath)
    })
    response.headers.add('Access-Control-Allow-Origin', '*')

    return response

if __name__ == "__main__":
    print("Starting Python Flask Server For Home Price Prediction...")
    util.load_saved_artifacts()
    app.run()