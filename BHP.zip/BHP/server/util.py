# import json
# import pickle
# import numpy as np
# #we create global variables
# __locations = None  # this will contain all the location
# __data_columns = None
# __model = None
#
# def get_estimated_price(location, sqft, bhk, bath): # this takes few args, and it has to return me with the price so we call our predict method in our model
#     #the behaviour of python list method is it throws error if element is not present so we put try and except in here
#     try:
#         loc_index = __data_columns.index(location.lower())  # here we datacolumns since it is a list and convert the location in it to lower
#     except:
#         loc_index = -1  # if it doesnt find index we initialize it to -1 to avoid error
#  # in above we use __columns bcoz it is a simply list
#     X = np.zeros(len(__data_columns))  # the no of zeros is len of datacolumns
#     X[0] = sqft
#     X[1] = bath
#     X[2] = bhk
#     # above three lines we have specified the index acc to it
#     if loc_index >= 0:  # for location we r using its index
#         X[loc_index] = 1  # once we have location index we can set it to 1 this will give the predicted price
# # we here use dummy hot and coding that is the reason we have lot of columns so to access particular column we write above loop it sets index col 1 and rest as 0
#         return round(__model.predict([X])[0], 2) # since we have sklearn saved model so we use predict method
# # the input it will take is a 2d array so we create a numpy array by copying the code that we already created in our notebook
# # thus once our model makes a prediction we get a 2d array since it will have only one element we can access the zeroth element in that will give the price in lakhs
# # hence we round it to two decimal numbers
#
# def get_location_names():
#     return __locations
#
#
# def load_saved_artifacts():  # this method will load the columns.json and pickle file which is our saved artifact
#     print("loading saved artifacts....start")
#     global __data_columns
#     global __locations  # on using global it will treat this variables as global var
#
#     # lets open the  json file
#     with open("./artifacts/columns.json", 'r') as f:  #here we r reading the file hence r as f
#         __data_columns = json.load(f)['data_columns']  # whatever object is loaded is converted into dictionary on which we can call datacolumns as key that will return all our columns
# #out of all datacol starting 3 are not locations so we use slicing to get element from the  list
#         __locations = __data_columns[3:] # this represents start index is 3
#
#         #we will also load our pickle model
#         global __model
#         with open("./artifacts/banglore_home_prices_model.pickle",'rb') as f :  # since it is binary code we use rb
#             __model = pickle.load(f)
#         print("loading saved artifacts is done....")
# # now we can say that loading the artifacts is done once this routine is done get_location_names can return locations
#
# if __name__ == '__main__':
#     load_saved_artifacts() # we should call this method inorder to get output
#     print(get_location_names())
#     print(get_estimated_price('1st Phase JP Nagar', 1000, 3, 3))
#     print(get_estimated_price('1st Phase JP Nagar', 1000, 2, 2))
#     print(get_estimated_price('Kalhalli', 1000, 2, 2)) # this comes under other location
#     print(get_estimated_price('Ejipura', 1000, 2, 2))
# # so this just returns the location names
# # here this function shou.d read the column .json and return the names , from 4th col since first 3 col are other features
# # on simply running this we will get all the locations
#
#
# # this is our first routine then we have to write a function that will return estimated price on specifying the location, bhk, bath etc..
# # lets write it above itself
#
# # so now our util file is ready lets add a route ending in server file


# REFER ABOVE CODE FOR UNDERSTANDING

import pickle
import json
import numpy as np

__locations = None
__data_columns = None
__model = None

def get_estimated_price(location,sqft,bhk,bath):
    try:
        loc_index = __data_columns.index(location.lower())
    except:
        loc_index = -1

    X = np.zeros(len(__data_columns))
    X[0] = sqft
    X[1] = bath
    X[2] = bhk
    if loc_index>=0:
        X[loc_index] = 1

    return round(__model.predict([X])[0],2)


def load_saved_artifacts():
    print("loading saved artifacts...start")
    global  __data_columns
    global __locations

    with open("./artifacts/columns.json", "r") as f:
        __data_columns = json.load(f)['data_columns']
        __locations = __data_columns[3:]  # first 3 columns are sqft, bath, bhk

    global __model
    if __model is None:
        with open('./artifacts/banglore_home_prices_model.pickle', 'rb') as f:
            __model = pickle.load(f)
    print("loading saved artifacts...done")

def get_location_names():
    return __locations

def get_data_columns():
    return __data_columns

if __name__ == '__main__':
    load_saved_artifacts()
    print(get_location_names())
    print(get_estimated_price('1st Phase JP Nagar',1000, 3, 3))
    print(get_estimated_price('1st Phase JP Nagar', 1000, 2, 2))
    print(get_estimated_price('Kalhalli', 1000, 2, 2)) # other location
    print(get_estimated_price('Ejipura', 1000, 2, 2))  # other location