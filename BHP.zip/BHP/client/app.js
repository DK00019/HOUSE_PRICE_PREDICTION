function onPageLoad(){
    console.log("document loaded")
    var url = "http://127.0.0.1:5000/get_location_names"; //on running this we willget locations which we save in data and then we jquery to make multiple select options
    $.get(url, function(date,status){
        console.log("got response for get_location_names request");
        if(data){
            var locations = data.locations;
            var uilocations = document.getElementById("uilocations");
            $('#uilocations').empty();
            for(var i in locations){
                var opt = new Option(locations[i]);
                $('#uilocations').append(opt)
            }
        }
    })
}

window.onload = onPageLoad;